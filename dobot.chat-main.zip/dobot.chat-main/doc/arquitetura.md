# Arquitetura do projeto

## Estrutura de pastas

```
```
