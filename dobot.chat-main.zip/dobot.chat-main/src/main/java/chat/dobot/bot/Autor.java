package chat.dobot.bot;

public enum Autor {
    USUARIO,
    BOT
}
