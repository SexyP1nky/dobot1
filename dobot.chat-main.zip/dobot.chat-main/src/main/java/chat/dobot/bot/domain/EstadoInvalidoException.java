package chat.dobot.bot.domain;

public class EstadoInvalidoException extends RuntimeException {
    public EstadoInvalidoException(String s) {
        super(s);
    }
}
